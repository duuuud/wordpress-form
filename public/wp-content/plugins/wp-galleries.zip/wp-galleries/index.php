<?php
// No access to plugin files